# Entry point for CLI
